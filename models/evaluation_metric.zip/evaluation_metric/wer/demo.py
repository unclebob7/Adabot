from wer import wer
from os import listdir
from statistics import mean
import re
import pickle

# pure_rpath = r"./trans_data/trans_pure/eval.code"
redundant_rpath = r"./trans_data/trans_redundant/eval.code"
# pure_epoch = r"./trans_data/trans_pure/"
redundant_epoch = r"./trans_data/trans_redundant/"
# pure_log_path = r"./trans_data/trans_pure/log/"
redundant_log_path = r"./trans_data/trans_redundant/log/"
# cwer_pure_path = r"./trans_data/trans_pure/log/cwer_pure"
cwer_redundant_path = r"./trans_data/trans_redundant/log/cwer_redundant"

# pure_r = [i.split() for i in open(pure_rpath, "r").readlines()]
redundant_r = [i.split() for i in open(redundant_rpath, "r").readlines()]

# pure_epoch_ls = listdir(pure_epoch)
redundant_epoch_ls = listdir(redundant_epoch)
# pure_epoch_ls.remove("eval.code")
# pure_epoch_ls.remove("log")
redundant_epoch_ls.remove("eval.code")
redundant_epoch_ls.remove("log")

# calculating wer of pure validation set of each epoch
# log_ls_pure = []
# cwer_pure = {}  # cumulative wer score of each epoch
# for fname in pure_epoch_ls:
#     h = [i.split() for i in open(pure_epoch+fname, "r").readlines()]
# #    del h[-1]
#     for item in range(len(h)):
#         result = wer(pure_r[item], h[item])
#         log_ls_pure.append(result)
#
#     with open(pure_log_path+fname[5:7]+r".txt", "w") as f:
#         for i in log_ls_pure:
#             f.write("%s\n" % i)
#     cwer_pure.update({fname[5:7]: mean([float(re.sub("%", "", i)) for i in log_ls_pure])})
#     log_ls_pure = []
    
# calculating wer of redundant validation set of each epoch
log_ls_redundant = []
cwer_redundant = [] # cumulative wer score of each epoch
for fname in redundant_epoch_ls:
   h = [i.split() for i in open(redundant_epoch+fname, "r").readlines()]
   for item in range(len(h)):
       result = wer(redundant_r[item], h[item])
       log_ls_redundant.append(result)

   with open(redundant_log_path+fname[5:7]+r".txt", "w") as f:
       for i in log_ls_redundant:
           f.write("%s\n" % i)
   cwer_redundant.append(mean([float(re.sub("%", "", i)) for i in log_ls_redundant]))
   log_ls_redundant = []
#    
# with open(cwer_pure_path, "wb") as f:
#     pickle.dump(cwer_pure, f)
#        
with open(cwer_redundant_path, "wb") as f:
   pickle.dump(cwer_redundant, f)
