#WER calculation in python

This file is written in python2.  

- Module needed:   
    - numpy  
- Usage:  
python wer.py reference.txt hypothesis.txt  
- Example:
![result](result.jpg)
