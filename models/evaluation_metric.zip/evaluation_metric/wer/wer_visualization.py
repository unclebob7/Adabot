import pickle
import matplotlib.pyplot as plt
import numpy as np

cwer_pure_path = r"/home/bob/EECS/python/NLP/word_error_rate/trans_data/ada_pure/log/cwer_pure"
#cwer_redundant_path = r"/home/bob/EECS/备份1/python/NLP/WER-in-python-master/eval/ada_redundant/log/cwer_redundant"

with open(cwer_pure_path, "rb") as f:
    cwr_pure = pickle.load(f)
    
#with open(cwer_redundant_path, "rb") as f:
#    cwr_redundant = pickle.load(f)
    
epoch = np.arange(1,21)

plt.figure(0)
plt.plot(epoch, cwer_pure, "ro")
plt.xticks(epoch)

#plt.figure(1)
#plt.plot(epoch, cwer_redundant, "bo")
#plt.xticks(epoch)