# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 15:48:47 2019

@author: admin
"""
import os

def calc_bleu(ref, translation):
    '''Calculates bleu score and appends the report to translation
    ref: reference file path
    translation: model output file path

    Returns
    translation that the bleu score is appended to'''
    get_bleu_score = "perl multi-bleu.perl {} < {} > {}".format(ref, translation, "temp")
    os.system(get_bleu_score)
    bleu_score_report = open("temp", "r+", encoding='utf-8').read()
    with open(translation, "a", encoding='utf-8') as fout:
        fout.write("\n{}".format(bleu_score_report))
    try:
        score = re.findall("BLEU = ([^,]+)", bleu_score_report)[0]
        new_translation = translation + "B{}".format(score)
        os.system("mv {} {}".format(translation, new_translation))
        os.remove(translation)

    except: pass
    os.remove("temp")



ref = "./1842_Test/pure/eval.code"
trans = "./test/pure/ada_E10L1.46-73680"
calc_bleu(ref, trans)