import sentencepiece as spm
from hparams import Hparams

hparams = Hparams()
parser = hparams.parser
hp = parser.parse_args()

train_bcode = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/train.bcode"
train_code = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/train.code"
eval_bcode = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/eval.bcode"
eval_code = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/eval.code"
test_bcode = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/test.bcode"
test_code = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/test.code"
train_path = r"/home/bob/Code/python/NLP/vanilla-transformer/transformer-master/data/prepro/train"

with open(train_bcode, "r") as f: train_bcode_src = [i.strip() for i in f.readlines()]
with open(train_code, "r") as f: train_code_src = [i.strip() for i in f.readlines()]
with open(eval_bcode, "r") as f: eval_bcode_src = [i.strip() for i in f.readlines()]
with open(eval_code, "r") as f: eval_code_src = [i.strip() for i in f.readlines()]
with open(test_bcode, "r") as f: test_bcode_src = [i.strip() for i in f.readlines()]
with open(test_code, "r") as f: test_code_src = [i.strip() for i in f.readlines()]

def _write(sents, fname):
    with open(fname, 'w') as fout:
        fout.write("\n".join(sents))
        
_write(train_code_src + train_bcode_src, train_path)

train = '--input=data/prepro/train --pad_id=0 --unk_id=1 \
         --bos_id=2 --eos_id=3\
         --model_prefix=data/segmented/bpe --vocab_size={} \
         --model_type=bpe'.format(hp.vocab_size)
spm.SentencePieceTrainer.Train(train)

sp = spm.SentencePieceProcessor()
sp.Load("data/segmented/bpe.model")

def _segment_and_write(sents, fname):
    with open(fname, "w") as fout:
        for sent in sents:
            pieces = sp.EncodeAsPieces(sent)
            fout.write(" ".join(pieces) + "\n")
            
_segment_and_write(train_bcode_src, "data/segmented/train.bcode.bpe")
_segment_and_write(train_code_src, "data/segmented/train.code.bpe")
_segment_and_write(eval_bcode_src, "data/segmented/eval.bcode.bpe")
_segment_and_write(eval_code_src, "data/segmented/eval.code.bpe")
_segment_and_write(test_bcode_src, "data/segmented/test.bcode.bpe")
_segment_and_write(test_code_src, "data/segmented/test.code.bpe")